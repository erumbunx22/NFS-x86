#!/system/bin/sh
/system/etc/injector/nfs1 2>/dev/null && /system/etc/injector/nfs2 2>/dev/null && /system/etc/injector/nfs3 2>/dev/null
exit 0
