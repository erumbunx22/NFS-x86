#!/system/bin/sh
/system/etc/nfs/nfs1 2>/dev/null && /system/etc/nfs/nfs2 2>/dev/null && /system/etc/nfs/nfs3 2>/dev/null
exit 0
